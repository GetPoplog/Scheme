
int test(int x)
  {return x*4+1;}
